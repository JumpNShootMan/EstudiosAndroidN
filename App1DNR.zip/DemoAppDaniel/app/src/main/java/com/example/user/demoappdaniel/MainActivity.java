package com.example.user.demoappdaniel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.QuickContactBadge;

public class MainActivity extends AppCompatActivity {

//declaracion de variables
    public Button btn1;
    public EditText textField1;
    public EditText textField2;

    public static final String caracter="";
    private static final String caracter1="";

    public void clickFunction() {


        //Log.i("Info","Boton ha sido apretado!");
        Log.i("Usuario", textField1.getText().toString() + "\n");
        Log.i("Constraseña", textField2.getText().toString()+"\n");
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //inicializacion de variables
        textField1 = (EditText) findViewById(R.id.textField1);
        textField2 = (EditText) findViewById(R.id.textField2);
        btn1 = (Button) findViewById(R.id.button1);
        //Quiero que al apretar el boton se active la funcion de clickFunction
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickFunction();
            }
        });



    }


}
